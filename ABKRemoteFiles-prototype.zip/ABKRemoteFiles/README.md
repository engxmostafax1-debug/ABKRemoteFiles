# ABK Remote Files — prototype source

This is an Android Kotlin starter project. It currently provides a simple HTTP file listing endpoint and a basic phone-2 connection screen. It is **not yet the complete requested product**.


## Important limitations
- Current file-server prototype is intended for a reachable network (e.g. same Wi-Fi). Cloud relay for devices on different networks is not implemented.
- The client UI currently displays the JSON directory response; interactive folder navigation and download UI still need implementation.
- Background server reliability is not guaranteed. Reliable background operation on modern Android generally requires foreground service/notification and platform permission constraints.
- All-files access can expose broad personal data. Grant only on your own device, use a strong password, and do not expose port 8787 directly to the public internet.
- Some Android folders remain restricted by OS even with broad storage access.

## Build
Open this folder in Android Studio, sync Gradle, then Build > Build APK. Or use the GitHub Actions workflow in `.github/workflows/android-build.yml` after uploading this project to a repository.
