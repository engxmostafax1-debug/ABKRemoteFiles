package com.abk.remotefiles

import android.os.Environment
import fi.iki.elonen.NanoHTTPD
import java.io.File
import java.net.URLDecoder
import java.util.concurrent.atomic.AtomicReference

object FileServer {
    private var server: NanoHTTPD? = null
    fun start(password: String) {
        if(server != null) return
        val root = Environment.getExternalStorageDirectory().canonicalFile
        server = object: NanoHTTPD(8787) {
            override fun serve(session: IHTTPSession): Response {
                val supplied = session.parameters["password"]?.firstOrNull().orEmpty()
                if(supplied != password) return newFixedLengthResponse(Response.Status.UNAUTHORIZED, "text/plain", "Unauthorized")
                val rel = session.parameters["path"]?.firstOrNull()?.let { URLDecoder.decode(it,"UTF-8") }.orEmpty()
                val target = File(root, rel).canonicalFile
                if(target != root && !target.path.startsWith(root.path + File.separator)) return newFixedLengthResponse(Response.Status.FORBIDDEN,"text/plain","Forbidden")
                if(session.uri == "/list") {
                    if(!target.exists() || !target.isDirectory) return newFixedLengthResponse(Response.Status.NOT_FOUND,"text/plain","Folder not found")
                    val listing=target.listFiles()?.sortedWith(compareBy<File>({!it.isDirectory}, {it.name.lowercase()}))?.map { f ->
                        "{\"name\":\"${f.name.replace("\\","\\\\").replace("\"","\\\"")}\",\"directory\":${f.isDirectory},\"size\":${f.length()}}"
                    }?.joinToString(",") ?: ""
                    return newFixedLengthResponse("application/json", "[$listing]")
                }
                if(session.uri == "/download") {
                    if(!target.exists() || !target.isFile) return newFixedLengthResponse(Response.Status.NOT_FOUND,"text/plain","File not found")
                    return newChunkedResponse(target.inputStream(), "application/octet-stream", target.length()).apply { addHeader("Content-Disposition", "attachment; filename=\"${target.name}\"") }
                }
                return newFixedLengthResponse(Response.Status.NOT_FOUND,"text/plain","Not found")
            }
        }
        server!!.start()
    }
}
