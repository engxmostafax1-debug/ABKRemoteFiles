package com.abk.remotefiles

import android.app.Activity
import android.os.Bundle
import android.os.Environment
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private fun addText(s: String, size: Float = 16f) { root.addView(TextView(this).apply { text=s; textSize=size; setPadding(12,10,12,10) }) }
    private fun field(hint: String): EditText = EditText(this).apply { this.hint=hint; setPadding(12,10,12,10); root.addView(this) }
    private fun button(s: String, fn: () -> Unit) { root.addView(Button(this).apply { text=s; setOnClickListener { fn() } }) }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); home() }
    private fun home() {
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,18,18,18) }
        setContentView(ScrollView(this).apply { addView(root) })
        addText("ABK Remote Files", 24f); addText("Prototype 0.1 — browsing and downloads")
        button("Phone 1 — Start file server") { serverScreen() }
        button("Phone 2 — Browse remote files") { clientScreen() }
        addText("Note: this prototype currently works over a reachable network (typically Wi-Fi/LAN). Remote internet relay is not included yet.")
    }
    private fun serverScreen() {
        root.removeAllViews(); addText("Phone 1 — Server",22f)
        addText("Grant file access in Android settings, then start server. This prototype does not guarantee background operation without a notification.")
        if (android.os.Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) button("Grant all-files access") { startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))) }
        val pw=field("Set access password")
        button("Start server") {
            if(pw.text.toString().length < 6) { toast("Password must be at least 6 characters"); return@button }
            FileServer.start(pw.text.toString())
            addText("Server started on port 8787. Find this phone's Wi-Fi IP in network settings and connect from Phone 2 using http://IP:8787");
        }
        button("Back") { home() }
    }
    private fun clientScreen() {
        root.removeAllViews(); addText("Phone 2 — Remote browser",22f)
        val host=field("Server address (e.g. http://192.168.1.20:8787)
        val pass=field("Password")
        val path=field("Folder path (blank = root)")
        button("List folder") { fetchList(host.text.toString().trim(), pass.text.toString(), path.text.toString().trim()) }
        button("Back") { home() }
    }
    private fun fetchList(host:String, password:String, path:String) {
        thread { try {
            val encoded=URLEncoder.encode(path,"UTF-8")
            val conn=URL(host.trimEnd('/')+"/list?path=$encoded&password="+URLEncoder.encode(password,"UTF-8")).openConnection() as HttpURLConnection
            conn.connectTimeout=10000; conn.readTimeout=10000
            val body=conn.inputStream.bufferedReader().readText(); runOnUiThread { addText(body) }
        } catch(e:Exception) { runOnUiThread { toast("Connection failed: ${e.message}") } } }
    }
    private fun toast(s:String) { Toast.makeText(this,s,Toast.LENGTH_LONG).show() }
}
